#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include "util.h"

#define MINARGS 3
#define USAGE "<inputFilePath> <outputFilePath>"
#define SBUFSIZE 1025
#define INPUTFS "%1024s"

int main(int argc, char* argv[]){

    //Local vars 
    FILE* inputfp = NULL;
    FILE* outputfp = NULL;
    char hostname[SBUFSIZE];
    char errorstr[SBUFSIZE];
    char firstipstr[INET6_ADDRSTRLEN];
    int i;
    
    //Make sure that there are the correctnumber of arguments
    if(argc < MINARGS){
	fprintf(stderr, "Not enough arguments: %d\n", (argc - 1));
	fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
	return EXIT_FAILURE;
    }

    //Open specified output file
    outputfp = fopen(argv[(argc-1)], "w");
    if(!outputfp){
	perror("Error Opening Output File");
	return EXIT_FAILURE;
    }

    //Num of input files
    for(i=1; i<(argc-1); i++){
		//Open them all
		inputfp = fopen(argv[i], "r");
		if(!inputfp){
		    sprintf(errorstr, "Error Opening Input File: %s \n", argv[i]);
		    perror(errorstr);
		    break;
	}	

	//Process the file
	while(fscanf(inputfp, INPUTFS, hostname) > 0){
	
	    //Runs the lookup in util.c, error check
	    if(dnslookup(hostname, firstipstr, sizeof(firstipstr))== UTIL_FAILURE){
			fprintf(stderr, "dnslookup error: %s\n", hostname);
			strncpy(firstipstr, "", sizeof(firstipstr));
	    }
	
	    //Write it to specified output file
	    fprintf(outputfp, "%s,%s\n", hostname, firstipstr);
	}

	//Close input
	fclose(inputfp);
    }

    //Close output
    fclose(outputfp);

    return EXIT_SUCCESS;
}
