#include <stdlib.h>

#include "multi-lookup.h"


// Thread Mutexes
pthread_mutex_t mutex;
pthread_mutex_t writeBlock;
pthread_mutex_t writeBlock2;
pthread_mutex_t readBlock;
pthread_mutex_t queueBlock;
pthread_mutex_t reportBlock;

//Global vars
int requestThreadsComplete = 0;
int readCount = 0;
int debug = 1;
int numRequestThreads = -1;
FILE* output2 = NULL;


void* RequestThread(void* threadarg){
    struct RequestData * requestData;
    char hostname[SBUFSIZE];
    FILE* inputfp;
    queue* q;
    char* payload;
    long threadNumber;

    requestData = (struct RequestData *) threadarg;

    pid_t x = syscall(__NR_gettid);
    if(debug){
    	printf("REQ THREAD ID: %d \n", x);
    }

//////////////////////////////
    pthread_mutex_lock(&writeBlock2);
	output2 = fopen("serviced.txt", "ab");
    if(!output2){
		perror("Error Opening Output service File");
		//return EXIT_FAILURE;
    }

  	fprintf(output2, "Thread %d serviced %d files.\n", x, requestData->filesServiced);

  	fclose(output2);
  	pthread_mutex_unlock(&writeBlock2);

/////////////////////////////


    for(int i = 0; i < requestData->inputFiles.size; i++){
        inputfp = requestData->inputFiles.array[i];

        q = requestData->q;
        threadNumber = requestData->threadNumber;


        // Open Input File
        if(!inputfp){
            printf("Error Opening Input File");
            pthread_exit(NULL);
        }

        // Add to queue
        if (debug){
        	printf("File being read\n");
        }

        
        while(fscanf(inputfp, INPUTFS, hostname) > 0){
            int completed = 0;
            while(!completed){
                // Check if queue is full
                pthread_mutex_lock(&readBlock);
                pthread_mutex_lock(&writeBlock);
                if (!queue_is_full(q)){
                    payload = malloc(SBUFSIZE);
                    strncpy(payload, hostname, SBUFSIZE);

                    if(debug){
                    	printf("Adding Payload to Queue:%s\n", payload);
                    }
                    queue_push(q, payload);
                    completed = 1;
                }
                // release queue
                pthread_mutex_unlock(&writeBlock);
                pthread_mutex_unlock(&readBlock);

                // Wait if not completed
                if (!completed){
                    usleep((rand()%100)*100000);
                }
            }
            //release queue
        }
        fclose(inputfp);
    }

    if(debug){
    	printf("Completing Request thread %ld\n", threadNumber);
	}
    return NULL;
}

void* ResolveThread(void* threadarg){
    struct ResolveData * resolveData;
    FILE* outputfp;
    char firstipstr[INET6_ADDRSTRLEN];
    char * hostname;
    queue* q;


    resolveData = (struct ResolveData *) threadarg;
    outputfp = resolveData->outputFile;
    q = resolveData->q;

     pid_t x = syscall(__NR_gettid);
     printf("RES THREAD ID: %d \n", x);

    int emptyQueue = 0;
    while (!emptyQueue || !requestThreadsComplete){
    	int resolved = 0;
        pthread_mutex_lock(&readBlock);
        pthread_mutex_lock(&mutex);
        readCount++;
        if (readCount==1){
            pthread_mutex_lock(&writeBlock);
        }
        pthread_mutex_unlock(&mutex);
        pthread_mutex_unlock(&readBlock);

        // Pop off the queue one at a time
        pthread_mutex_lock(&queueBlock);
        emptyQueue = queue_is_empty(q);
        if(!emptyQueue){
            hostname = queue_pop(q);
            if (hostname != NULL){
            	if(debug){
            		printf("Getting IP for: %s\n", hostname);
            	}
	            resolved = 1;
        	}
        }
        pthread_mutex_unlock(&queueBlock);

        pthread_mutex_lock(&mutex);
        readCount--;
        if (readCount == 0){
            pthread_mutex_unlock(&writeBlock);
        }
        pthread_mutex_unlock(&mutex);

        if(resolved){
        	queue dnsList;
        	queue_init(&dnsList, 50);
            if(dnslookupall(hostname, firstipstr, sizeof(firstipstr), &dnsList) == UTIL_FAILURE){
                fprintf(stderr, "dnslookup error: %s\n", hostname);
                strncpy(firstipstr, "", sizeof(firstipstr));
            }
            fprintf(outputfp, "%s", hostname);
    		char * element;
    		pthread_mutex_lock(&reportBlock);
            while( (element = (char *) queue_pop(&dnsList)) != NULL){
		    	fprintf(outputfp, ",%s", element);
		    	free(element);
		    }
		    fprintf(outputfp, "\n");
            pthread_mutex_unlock(&reportBlock);
		    free(hostname);
		    queue_cleanup(&dnsList);
        }

    }

    if(debug){
    	printf("Complete Resolve thread\n");
    }

    return NULL;
}

long long current_timestamp() {
    struct timeval te; 
    gettimeofday(&te, NULL); // get current time
    long long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000; // caculate milliseconds
    // printf("milliseconds: %lld\n", milliseconds);
    return milliseconds;
}


int main(int argc, char* argv[]){
	//The start time
	long startTime = current_timestamp();
	//printf("Starting at Time: %d \n", startTime);

	remove("serviced.txt");

	/* Local Vars */
    FILE* outputfp = NULL;

    /* Check Arguments */
    if(argc < MINARGS){
		fprintf(stderr, "Not enough arguments: %d\n", (argc - 1));
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    }
    if (argc > NUM_THREADS + 1){
    	fprintf(stderr, "Too many files: %d\n", (argc - 2));
    	fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    }

    /* Open Output File */
    outputfp = fopen(argv[(argc-1)], "w");
    if(!outputfp){
		perror("Error Opening Output File");
		return EXIT_FAILURE;
    }

    // Build Queue
    queue q;
    const int qSize = TEST_SIZE;
    if(queue_init(&q, qSize) == QUEUE_FAILURE){
		fprintf(stderr, "error: queue_init failed!\n");
    }


    /////////////////////////////////////////////////
    // Create REQUEST Thread Pool
    /////////////////////////////////////////////////
    struct RequestData requestData[NUM_THREADS];
    pthread_t requestThreads[NUM_THREADS];
    int rc;
    long t;

    sscanf (argv[1],"%d",&numRequestThreads);

    numRequestThreads = (numRequestThreads > 5) ? 5 : numRequestThreads;

    if (numRequestThreads == -1){
        /*
        throw error
        should never get here though because above we check for minimum
         of 3 args therefor argv[1] never stays -1 unless scanf function fails
         */
        printf("WARNING: numRequestThreads Should not be -1, incorrect output likely");

    }

    int filesPerThread[numRequestThreads];

    int numFiles = 5;

    if (numFiles > numRequestThreads){
        // int x = 5 % numRequestThreads;
        int remainingFiles = 5;
        int fpt = 5 / numRequestThreads;

         for(int i = 0; i < numRequestThreads; i++){
            filesPerThread[i] = fpt;
            remainingFiles -= fpt;
         }

         filesPerThread[0] += remainingFiles;

    }else{
         for(int i = 0; i < numRequestThreads; i++){
            filesPerThread[i] = 1;
         }
    }

    // if(numFiles%2 == 0){
    //     for(int i = 0; i < numRequestThreads; i++){

    //     }
    // }

    int offset = 0;

    for(t=0; t < numRequestThreads && t<NUM_THREADS; t++){
        requestData[t].q = &q;

        requestData[t].inputFiles.size = filesPerThread[t];

        int numFiles = filesPerThread[t];

        for(int i = 0; i < numFiles; i++){
            requestData[t].inputFiles.array[i] = fopen(argv[t+offset+3], "r");
            printf("%s\n", argv[t+offset+3]);
            if(numFiles > 1 && i != numFiles - 1){
                offset++;
            }
        }

        requestData[t].threadNumber = t;

        //unsigned long int requestThreadId = requestThreads[t];
        requestData[t].filesServiced = numFiles;
        if (debug){
        	printf("Creating REQUEST Thread %ld\n", t+1);
    		printf("REQUESTER thread files serviced: %d \n\n", numFiles);
        }
		rc = pthread_create(&(requestThreads[t]), NULL, RequestThread, &(requestData[t]));
		if (rc){
		    printf("ERROR; return code from pthread_create() is %d\n", rc);
		    exit(EXIT_FAILURE);
		}
    }


    /////////////////////////////////////////////////
    // Create RESOLVE Thread Pool
    /////////////////////////////////////////////////
    struct ResolveData resolveData;
    //int cpuCoreCount = sysconf(_SC_NPROCESSORS_ONLN);
    int numResolveThreads;
    sscanf (argv[2],"%d",&numResolveThreads);

    pthread_t resolveThreads[numResolveThreads];
    int rc2;
    long t2;


    resolveData.q = &q;
    resolveData.outputFile = outputfp;

    /* Spawn RESOLVE threads */

    for(t2=0; t2<numResolveThreads; t2++){
    	if (debug){
    		printf("Creating RESOLVER Thread %ld\n", t2);
    		//unsigned long int resolveThreadId = resolveThreads[t2];
    	}
        rc2 = pthread_create(&(resolveThreads[t2]), NULL, ResolveThread, &resolveData);
        if (rc2){
            printf("ERROR; return code from pthread_create() is %d\n", rc2);
            exit(EXIT_FAILURE);
        }
    }

    //Join Threads to detect completion
    for(t=0; t<numRequestThreads && t<NUM_THREADS; t++){
        pthread_join(requestThreads[t],NULL);
    }
    if (debug){
    	printf("REQ THREADS DONE\n");
    }
    requestThreadsComplete = 1;

    //Join Threads to detect completion
    for(t=0; t<numResolveThreads; t++){
        pthread_join(resolveThreads[t],NULL);
    }
    if (debug){
    	printf("RES THREADS DONE\n");
    }

    /* Close Output File */
    fclose(outputfp);

    /* Cleanup Queue */
    queue_cleanup(&q);

    //Calculate time taken

    long endTime = current_timestamp();

    //printf("Finished at time: %d \n", endTime);

    long elapsedTime = (endTime - startTime);

    printf("Elapsed Time: %ld seconds\n", elapsedTime/1000);

    return EXIT_SUCCESS;
}
