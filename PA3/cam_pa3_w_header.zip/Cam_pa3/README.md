CAMERON CONNOR

How to build and run:

Build
1. cd into directory containging make file
2. Command make

Run
1. Command: ./multi-lookup [# req threads] [# res threads] [input files] [output file]

Before Rebuild
1. Command: make clean
