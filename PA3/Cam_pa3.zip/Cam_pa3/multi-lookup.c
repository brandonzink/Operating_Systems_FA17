#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include "util.h"
#include "queue.h"

#define MINARGS 3
#define USAGE "<inputFilePath> <outputFilePath>"
#define SBUFSIZE 1025
#define INPUTFS "%1024s"
#define TEST_SIZE 10
#define NUM_THREADS 10

// Thread Data Structures
struct dynamicArray{
    FILE *array[5]; //max size is 5
    int size; //need to indicate when array isn't full to avoid looping through empty indices
    //because causes seg fault
};

struct RequestData{
    long threadNumber;
    struct dynamicArray inputFiles;
    queue* q;
    int filesServiced;
};

struct ResolveData{
    FILE* outputFile;
    queue* q;
};

// Thread Mutexes
pthread_mutex_t mutex;
pthread_mutex_t writeBlock;
pthread_mutex_t readBlock;
pthread_mutex_t servicedWriteBlock;
pthread_mutex_t queueBlock;
pthread_mutex_t reportBlock;

int requestThreadsComplete = 0;
int readCount = 0;
int debug = 1;
int numRequestThreads = -1;


void* RequestThread(void* threadarg){
    struct RequestData * requestData;
    char hostname[SBUFSIZE];
    char* payload;
    long threadNumber;
    FILE* inputfp;
    queue* q;
    FILE* outputFilePath = NULL;


    requestData = (struct RequestData *) threadarg;

    pid_t x = syscall(__NR_gettid); //get thread ID
    if(debug){
        printf("*************Requester Thread ID: %d \n", x); //print it out
    }

    pthread_mutex_lock(&servicedWriteBlock);

    outputFilePath = fopen("serviced.txt", "ab"); //open output file
    if(!outputFilePath){ //check to make sure it opens
        perror("Error Opening Output File"); //print error
    }else{
        fprintf(outputFilePath, "Request Thread ID, # Files Serviced: %d,%d\n", x, requestData->filesServiced);
    }

    fclose(outputFilePath);

    pthread_mutex_unlock(&servicedWriteBlock);


    for(int i = 0; i < requestData->inputFiles.size; i++){ //loop through all files given to thread
        inputfp = requestData->inputFiles.array[i];

        // inputfp = requestData->inputFile;
        q = requestData->q; //get threads queue
        threadNumber = requestData->threadNumber;


        // Open Input File
        if(!inputfp){
            printf("Error Opening Input File");
            pthread_exit(NULL);
        }

        // Add to queue
        if (debug){
        	printf("File being read\n");
        }

        
        while(fscanf(inputfp, INPUTFS, hostname) > 0){
            int completed = 0;
            while(!completed){
                // Check if queue is full
                pthread_mutex_lock(&readBlock); //Lock  mutext to prevent other threads from accessing queue
                pthread_mutex_lock(&writeBlock); //thread safety!
                if (!queue_is_full(q)){
                    payload = malloc(SBUFSIZE);
                    strncpy(payload, hostname, SBUFSIZE); //copy domain name

                    if(debug){
                    	printf("Adding Payload to Queue:%s\n", payload);
                    }
                    queue_push(q, payload); //push dns name to queue
                    completed = 1;
                }
                // release queue
                pthread_mutex_unlock(&writeBlock); //release queue
                pthread_mutex_unlock(&readBlock);

                // Wait if not completed
                if (!completed){
                    usleep((rand()%100)*100000);
                }
            }
            //release queue
        }
        fclose(inputfp);
    }

    if(debug){
    	printf("Completing Request thread %ld\n", threadNumber);
	}

    return NULL;
}

void* ResolveThread(void* threadarg){
    struct ResolveData * resolveData;
    char firstipstr[INET6_ADDRSTRLEN];
    char * hostname;

    FILE* outputfp;
    queue* q;


    resolveData = (struct ResolveData *) threadarg;
    outputfp = resolveData->outputFile;
    q = resolveData->q;


    pid_t x = syscall(__NR_gettid);
    printf("************Resolver Thread ID: %d \n", x);

    int emptyQueue = 0;

    while (!emptyQueue || !requestThreadsComplete){ //loop through entire queue created from requester threads
    	int resolved = 0;
        pthread_mutex_lock(&readBlock);
        pthread_mutex_lock(&mutex);
        readCount++;
        if (readCount==1){
            pthread_mutex_lock(&writeBlock);
        }
        pthread_mutex_unlock(&mutex);
        pthread_mutex_unlock(&readBlock);

        // Pop off the queue one at a time
        pthread_mutex_lock(&queueBlock);
        emptyQueue = queue_is_empty(q);
        if(!emptyQueue){
            hostname = queue_pop(q);
            if (hostname != NULL){
            	if(debug){
            		printf("Reading Host From Queue: %s\n", hostname);
            	}
	            resolved = 1;
        	}
        }
        pthread_mutex_unlock(&queueBlock);

        pthread_mutex_lock(&mutex);
        readCount--;
        if (readCount == 0){
            pthread_mutex_unlock(&writeBlock);
        }
        pthread_mutex_unlock(&mutex);

        if(resolved){ //succesfully got hostname from queue, now lookup ip address
        	queue dnsList;
        	queue_init(&dnsList, 50);
            if(dnslookupall(hostname, firstipstr, sizeof(firstipstr), &dnsList) == UTIL_FAILURE){
                fprintf(stderr, "dnslookup error: %s\n", hostname);
                strncpy(firstipstr, "", sizeof(firstipstr));
            }
            fprintf(outputfp, "%s", hostname);
    		char * element;
    		pthread_mutex_lock(&reportBlock);
            while( (element = (char *) queue_pop(&dnsList)) != NULL){
		    	fprintf(outputfp, ",%s", element);
		    	free(element);
		    }
		    fprintf(outputfp, "\n");
            pthread_mutex_unlock(&reportBlock);
		    free(hostname);
		    queue_cleanup(&dnsList);
        }

    }

    if(debug){
    	printf("Complete Resolve thread\n");
    }

    return NULL;
}

long long current_timestamp() {
    struct timeval te; 
    gettimeofday(&te, NULL); // get current time
    long long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000; // caculate milliseconds
    // printf("milliseconds: %lld\n", milliseconds);
    return milliseconds;
}


int main(int argc, char* argv[]){

    pthread_mutex_lock(&servicedWriteBlock);

    FILE* outputFilePath = fopen("serviced.txt", "w"); //open output file
    if(!outputFilePath){ //check to make sure it opens
        perror("Error Opening Output File"); //print error
    }else{
        fprintf(outputFilePath, "\n");
    }

    fclose(outputFilePath);
    pthread_mutex_unlock(&servicedWriteBlock);


	long startTime = current_timestamp();
	printf("Starting at Time: %ld \n", startTime);

	/* Local Vars */
    FILE* outputfp = NULL;

    /* Check Arguments */
    if(argc < MINARGS){
		fprintf(stderr, "Not enough arguments: %d\n", (argc - 1));
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    }
    if (argc > NUM_THREADS + 1){
    	fprintf(stderr, "Too many files: %d\n", (argc - 2));
    	fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    }

    /* Open Output File */
    outputfp = fopen(argv[(argc-1)], "w");
    if(!outputfp){
		perror("Error Opening Output File");
		return EXIT_FAILURE;
    }

    // Build Queue
    queue q;
    const int qSize = TEST_SIZE;
    if(queue_init(&q, qSize) == QUEUE_FAILURE){
		fprintf(stderr, "error: queue_init failed!\n");
    }


    /////////////////////////////////////////////////
    // Create REQUEST Thread Pool
    /////////////////////////////////////////////////
    struct RequestData requestData[NUM_THREADS];
    pthread_t requestThreads[NUM_THREADS];
    int rc;
    long t;

    sscanf (argv[1],"%d",&numRequestThreads);

    numRequestThreads = (numRequestThreads > 5) ? 5 : numRequestThreads;

    if (numRequestThreads == -1){
        /*
        throw error
        should never get here though because above we check for minimum
         of 3 args therefor argv[1] never stays -1 unless scanf function fails
         */
        printf("WARNING: numRequestThreads Should not be -1, incorrect output likely");

    }

    int filesPerThread[numRequestThreads];

    int numFiles = 5;

    if (numFiles > numRequestThreads){
        // int x = 5 % numRequestThreads;
        int remainingFiles = 5;
        int fpt = 5 / numRequestThreads;

         for(int i = 0; i < numRequestThreads; i++){
            filesPerThread[i] = fpt;
            remainingFiles -= fpt;
         }

         filesPerThread[0] += remainingFiles;

    }else{
         for(int i = 0; i < numRequestThreads; i++){
            filesPerThread[i] = 1;
         }
    }

    // if(numFiles%2 == 0){
    //     for(int i = 0; i < numRequestThreads; i++){

    //     }
    // }

    int offset = 0;

    for(t=0; t < numRequestThreads && t<NUM_THREADS; t++){
        requestData[t].q = &q;

        requestData[t].inputFiles.size = filesPerThread[t];

        int numFiles = filesPerThread[t];
        requestData[t].filesServiced = numFiles;


        for(int i = 0; i < numFiles; i++){
            requestData[t].inputFiles.array[i] = fopen(argv[t+offset+3], "r");
            printf("%s\n", argv[t+offset+3]);
            if(numFiles > 1 && i != numFiles - 1){
                offset++;
            }
        }

        requestData[t].threadNumber = t;

        if (debug){
        	printf("Creating REQUEST Thread %ld\n", t+1);
        }
		rc = pthread_create(&(requestThreads[t]), NULL, RequestThread, &(requestData[t]));
		if (rc){
		    printf("ERROR; return code from pthread_create() is %d\n", rc);
		    exit(EXIT_FAILURE);
		}else{
			// unsigned long int requestThreadId = requestThreads[t];
    		// printf("REQUESTER thread  %d has ID:  %d \n", t+1, requestThreadId);
    		printf("REQUESTER thread files serviced: %d \n\n", numFiles);
		}
    }

    /////////////////////////////////////////////////
    // Create RESOLVE Thread Pool
    /////////////////////////////////////////////////

    struct ResolveData resolveData;
    //int cpuCoreCount = sysconf(_SC_NPROCESSORS_ONLN);
    int numResolveThreads;
    sscanf (argv[2],"%d",&numResolveThreads);

    pthread_t resolveThreads[numResolveThreads];
    int rc2;
    long t2;


    resolveData.q = &q;
    resolveData.outputFile = outputfp;

    /* Spawn RESOLVE threads */

    for(t2=0; t2<numResolveThreads; t2++){
    	if (debug){
    		printf("Creating RESOLVER Thread %ld\n", t2);
    	}
        rc2 = pthread_create(&(resolveThreads[t2]), NULL, ResolveThread, &resolveData);
        if (rc2){
            printf("ERROR; return code from pthread_create() is %d\n", rc2);
            exit(EXIT_FAILURE);
        }else{
			// unsigned long int resolveThreadId = resolveThreads[t2];
    		// printf("RESOLVER thread %d has ID:  %d \n\n", t2, resolveThreadId);
        }
    }

    //Join Threads to detect completion
    for(t=0; t<numRequestThreads && t<NUM_THREADS; t++){
        pthread_join(requestThreads[t],NULL);
    }
    if (debug){
    	printf("All Request threads have FINISHED!\n");
    }
    requestThreadsComplete = 1;

    //Join Threads to detect completion
    for(t=0; t<numResolveThreads; t++){
        pthread_join(resolveThreads[t],NULL);
    }
    if (debug){
    	printf("All Resolver threads have FINISHED!\n");
    }

    /* Close Output File */
    fclose(outputfp);

    /* Cleanup Queue */
    queue_cleanup(&q);

    long endTime = current_timestamp();

    printf("Finished at time: %ld \n", endTime);

    long elapsedTime = (startTime - endTime) * -1; //LOL, no time for (secapskcab)*-1

    printf("Elapsed Time: %ld \n", elapsedTime);

    return EXIT_SUCCESS;
}
