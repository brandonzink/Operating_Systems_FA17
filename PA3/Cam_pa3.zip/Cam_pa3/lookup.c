#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include "util.h"

#define MIN_ARGS 3
#define USAGE "<inputFilePath> <outputFilePath>"
#define SBUFSIZE 1025
#define INPUT_FS "%1024s"

int main(int argc, char* argv[]){

    FILE* inputFilePath = NULL;
    FILE* outputFilePath = NULL;

    char hostname[SBUFSIZE];
    char errorstr[SBUFSIZE];
    char firstipstr[INET6_ADDRSTRLEN];
    
    if(argc < MIN_ARGS){
		fprintf(stderr, "More arguments required: %d\n", (argc - 1));
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    }

    outputFilePath = fopen(argv[(argc-1)], "w"); //open output file
    if(!outputFilePath){ //check to make sure it opens
	perror("Error Opening Output File"); //print error
	return EXIT_FAILURE;
    }

    for(int i=1; i<(argc-1); i++){ //looping through all input files
	
	inputFilePath = fopen(argv[i], "r"); //open input file i
	if(!inputFilePath){
	    sprintf(errorstr, "Error Opening Input File: %s \n", argv[i]);
	    perror(errorstr);
	    break;
	}	

	while(fscanf(inputFilePath, INPUT_FS, hostname) > 0){ //read text from file
	
	    if(dnslookup(hostname, firstipstr, sizeof(firstipstr)) == UTIL_FAILURE){ //get ip address(es) from hostname
			//dnslookup has function addToDnsQueue which is what allows for multiple ip addresses
			// to be written to output file for single domain
		fprintf(stderr, "dnslookup error: %s\n", hostname);
		strncpy(firstipstr, "", sizeof(firstipstr));
	    }
	
	    /* Write to Output File */
	    fprintf(outputFilePath, "%s,%s\n", hostname, firstipstr); //write hostname and ip address to file
	}

	/* Close Input File */
	fclose(inputFilePath);
    }

    /* Close Output File */
    fclose(outputFilePath);

    return EXIT_SUCCESS;
}
